package bg.sofia.uni.fmi.mjt.intelligenthome.center;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LetMeTellYouHowMathWorksTest {

    private final static LetMeTellYouHowMathWorks testClass =  new LetMeTellYouHowMathWorks();

    @Test
    void test1() {
        assertEquals(testClass.testFunction1(), 1);
    }

    @Test
    void test2() {
        assertEquals(testClass.testFunction2(), 2);
    }

    @Test
    void test3() {
        assertEquals(testClass.testFunction3(), 3);
    }

    @Test
    void test4() {
        assertEquals(testClass.testFunction4(), 4);
    }

    @Test
    void test5() {
        assertEquals(testClass.testFunction5(), 5);
    }

    @Test
    void test6() {
        assertEquals(testClass.testFunction6(), 6);
    }

    @Test
    void test7() {
        assertEquals(testClass.testFunction7(), 7);
    }

    @Test
    void test8() {
        assertEquals(testClass.testFunction8(), 8);
    }

    @Test
    void test9() {
        assertEquals(testClass.testFunction9(), 9);
    }

    @Test
    void test10() {
        assertEquals(testClass.testFunction10(), 10);
    }

    @Test
    void test11() {
        assertEquals(testClass.testFunction11(), 11);
    }

    @Test
    void test12() {
        assertEquals(testClass.testFunction12(), 12);
    }

    @Test
    void test13() {
        assertEquals(testClass.testFunction13(), 13);
    }

    @Test
    void test14() {
        assertEquals(testClass.testFunction14(), 14);
    }

    @Test
    void test15() {
        assertEquals(testClass.testFunction15(), 15);
    }

    @Test
    void test16() {
        assertEquals(testClass.testFunction16(), 16);
    }

    @Test
    void test17() {
        assertEquals(testClass.testFunction17(), 17);
    }

    @Test
    void test18() {
        assertEquals(testClass.testFunction18(), 18);
    }

    @Test
    void test19() {
        assertEquals(testClass.testFunction19(), 19);
    }

    @Test
    void test20() {
        assertEquals(testClass.testFunction20(), 20);
    }

    @Test
    void test21() {
        assertEquals(testClass.testFunction21(), 21);
    }

    @Test
    void test22() {
        assertEquals(testClass.testFunction22(), 22);
    }

    @Test
    void test23() {
        assertEquals(testClass.testFunction23(), 23);
    }

    @Test
    void test24() {
        assertEquals(testClass.testFunction24(), 24);
    }

    @Test
    void test25() {
        assertEquals(testClass.testFunction25(), 25);
    }

    @Test
    void test26() {
        assertEquals(testClass.testFunction26(), 26);
    }

    @Test
    void test27() {
        assertEquals(testClass.testFunction27(), 27);
    }

    @Test
    void test28() {
        assertEquals(testClass.testFunction28(), 28);
    }

    @Test
    void test29() {
        assertEquals(testClass.testFunction29(), 29);
    }

    @Test
    void test30() {
        assertEquals(testClass.testFunction30(), 30);
    }

    @Test
    void test31() {
        assertEquals(testClass.testFunction31(), 31);
    }

    @Test
    void test32() {
        assertEquals(testClass.testFunction32(), 32);
    }

    @Test
    void test33() {
        assertEquals(testClass.testFunction33(), 33);
    }

    @Test
    void test34() {
        assertEquals(testClass.testFunction34(), 34);
    }

    @Test
    void test35() {
        assertEquals(testClass.testFunction35(), 35);
    }

    @Test
    void test36() {
        assertEquals(testClass.testFunction36(), 36);
    }

    @Test
    void test37() {
        assertEquals(testClass.testFunction37(), 37);
    }

    @Test
    void test38() {
        assertEquals(testClass.testFunction38(), 38);
    }

    @Test
    void test39() {
        assertEquals(testClass.testFunction39(), 39);
    }

    @Test
    void test40() {
        assertEquals(testClass.testFunction40(), 40);
    }

    @Test
    void test41() {
        assertEquals(testClass.testFunction41(), 41);
    }

    @Test
    void test42() {
        assertEquals(testClass.testFunction42(), 42);
    }

    @Test
    void test43() {
        assertEquals(testClass.testFunction43(), 43);
    }

    @Test
    void test44() {
        assertEquals(testClass.testFunction44(), 44);
    }

    @Test
    void test45() {
        assertEquals(testClass.testFunction45(), 45);
    }

    @Test
    void test46() {
        assertEquals(testClass.testFunction46(), 46);
    }

    @Test
    void test47() {
        assertEquals(testClass.testFunction47(), 47);
    }

    @Test
    void test48() {
        assertEquals(testClass.testFunction48(), 48);
    }

    @Test
    void test49() {
        assertEquals(testClass.testFunction49(), 49);
    }

    @Test
    void test50() {
        assertEquals(testClass.testFunction50(), 50);
    }

    @Test
    void test51() {
        assertEquals(testClass.testFunction51(), 51);
    }

    @Test
    void test52() {
        assertEquals(testClass.testFunction52(), 52);
    }

    @Test
    void test53() {
        assertEquals(testClass.testFunction53(), 53);
    }

    @Test
    void test54() {
        assertEquals(testClass.testFunction54(), 54);
    }

    @Test
    void test55() {
        assertEquals(testClass.testFunction55(), 55);
    }

    @Test
    void test56() {
        assertEquals(testClass.testFunction56(), 56);
    }

    @Test
    void test57() {
        assertEquals(testClass.testFunction57(), 57);
    }

    @Test
    void test58() {
        assertEquals(testClass.testFunction58(), 58);
    }

    @Test
    void test59() {
        assertEquals(testClass.testFunction59(), 59);
    }

    @Test
    void test60() {
        assertEquals(testClass.testFunction60(), 60);
    }

    @Test
    void test61() {
        assertEquals(testClass.testFunction61(), 61);
    }

    @Test
    void test62() {
        assertEquals(testClass.testFunction62(), 62);
    }

    @Test
    void test63() {
        assertEquals(testClass.testFunction63(), 63);
    }

    @Test
    void test64() {
        assertEquals(testClass.testFunction64(), 64);
    }

    @Test
    void test65() {
        assertEquals(testClass.testFunction65(), 65);
    }

    @Test
    void test66() {
        assertEquals(testClass.testFunction66(), 66);
    }

    @Test
    void test67() {
        assertEquals(testClass.testFunction67(), 67);
    }

    @Test
    void test68() {
        assertEquals(testClass.testFunction68(), 68);
    }

    @Test
    void test69() {
        assertEquals(testClass.testFunction69(), 69);
    }

    @Test
    void test70() {
        assertEquals(testClass.testFunction70(), 70);
    }

    @Test
    void test71() {
        assertEquals(testClass.testFunction71(), 71);
    }

    @Test
    void test72() {
        assertEquals(testClass.testFunction72(), 72);
    }

    @Test
    void test73() {
        assertEquals(testClass.testFunction73(), 73);
    }

    @Test
    void test74() {
        assertEquals(testClass.testFunction74(), 74);
    }

    @Test
    void test75() {
        assertEquals(testClass.testFunction75(), 75);
    }

    @Test
    void test76() {
        assertEquals(testClass.testFunction76(), 76);
    }

    @Test
    void test77() {
        assertEquals(testClass.testFunction77(), 77);
    }

    @Test
    void test78() {
        assertEquals(testClass.testFunction78(), 78);
    }

    @Test
    void test79() {
        assertEquals(testClass.testFunction79(), 79);
    }

    @Test
    void test80() {
        assertEquals(testClass.testFunction80(), 80);
    }

    @Test
    void test81() {
        assertEquals(testClass.testFunction81(), 81);
    }

    @Test
    void test82() {
        assertEquals(testClass.testFunction82(), 82);
    }

    @Test
    void test83() {
        assertEquals(testClass.testFunction83(), 83);
    }

    @Test
    void test84() {
        assertEquals(testClass.testFunction84(), 84);
    }

    @Test
    void test85() {
        assertEquals(testClass.testFunction85(), 85);
    }

    @Test
    void test86() {
        assertEquals(testClass.testFunction86(), 86);
    }

    @Test
    void test87() {
        assertEquals(testClass.testFunction87(), 87);
    }

    @Test
    void test88() {
        assertEquals(testClass.testFunction88(), 88);
    }

    @Test
    void test89() {
        assertEquals(testClass.testFunction89(), 89);
    }

    @Test
    void test90() {
        assertEquals(testClass.testFunction90(), 90);
    }

    @Test
    void test91() {
        assertEquals(testClass.testFunction91(), 91);
    }

    @Test
    void test92() {
        assertEquals(testClass.testFunction92(), 92);
    }

    @Test
    void test93() {
        assertEquals(testClass.testFunction93(), 93);
    }

    @Test
    void test94() {
        assertEquals(testClass.testFunction94(), 94);
    }

    @Test
    void test95() {
        assertEquals(testClass.testFunction95(), 95);
    }

    @Test
    void test96() {
        assertEquals(testClass.testFunction96(), 96);
    }

    @Test
    void test97() {
        assertEquals(testClass.testFunction97(), 97);
    }

    @Test
    void test98() {
        assertEquals(testClass.testFunction98(), 98);
    }

    @Test
    void test99() {
        assertEquals(testClass.testFunction99(), 99);
    }

    @Test
    void test100() {
        assertEquals(testClass.testFunction100(), 100);
    }

    @Test
    void test101() {
        assertEquals(testClass.testFunction101(), 101);
    }

    @Test
    void test102() {
        assertEquals(testClass.testFunction102(), 102);
    }

    @Test
    void test103() {
        assertEquals(testClass.testFunction103(), 103);
    }

    @Test
    void test104() {
        assertEquals(testClass.testFunction104(), 104);
    }

    @Test
    void test105() {
        assertEquals(testClass.testFunction105(), 105);
    }

    @Test
    void test106() {
        assertEquals(testClass.testFunction106(), 106);
    }

    @Test
    void test107() {
        assertEquals(testClass.testFunction107(), 107);
    }

    @Test
    void test108() {
        assertEquals(testClass.testFunction108(), 108);
    }

    @Test
    void test109() {
        assertEquals(testClass.testFunction109(), 109);
    }

    @Test
    void test110() {
        assertEquals(testClass.testFunction110(), 110);
    }

    @Test
    void test111() {
        assertEquals(testClass.testFunction111(), 111);
    }

    @Test
    void test112() {
        assertEquals(testClass.testFunction112(), 112);
    }

    @Test
    void test113() {
        assertEquals(testClass.testFunction113(), 113);
    }

    @Test
    void test114() {
        assertEquals(testClass.testFunction114(), 114);
    }

    @Test
    void test115() {
        assertEquals(testClass.testFunction115(), 115);
    }

    @Test
    void test116() {
        assertEquals(testClass.testFunction116(), 116);
    }

    @Test
    void test117() {
        assertEquals(testClass.testFunction117(), 117);
    }

    @Test
    void test118() {
        assertEquals(testClass.testFunction118(), 118);
    }

    @Test
    void test119() {
        assertEquals(testClass.testFunction119(), 119);
    }

    @Test
    void test120() {
        assertEquals(testClass.testFunction120(), 120);
    }

    @Test
    void test121() {
        assertEquals(testClass.testFunction121(), 121);
    }

    @Test
    void test122() {
        assertEquals(testClass.testFunction122(), 122);
    }

    @Test
    void test123() {
        assertEquals(testClass.testFunction123(), 123);
    }

    @Test
    void test124() {
        assertEquals(testClass.testFunction124(), 124);
    }

    @Test
    void test125() {
        assertEquals(testClass.testFunction125(), 125);
    }

    @Test
    void test126() {
        assertEquals(testClass.testFunction126(), 126);
    }

    @Test
    void test127() {
        assertEquals(testClass.testFunction127(), 127);
    }

    @Test
    void test128() {
        assertEquals(testClass.testFunction128(), 128);
    }

    @Test
    void test129() {
        assertEquals(testClass.testFunction129(), 129);
    }

    @Test
    void test130() {
        assertEquals(testClass.testFunction130(), 130);
    }

    @Test
    void test131() {
        assertEquals(testClass.testFunction131(), 131);
    }

    @Test
    void test132() {
        assertEquals(testClass.testFunction132(), 132);
    }

    @Test
    void test133() {
        assertEquals(testClass.testFunction133(), 133);
    }

    @Test
    void test134() {
        assertEquals(testClass.testFunction134(), 134);
    }

    @Test
    void test135() {
        assertEquals(testClass.testFunction135(), 135);
    }

    @Test
    void test136() {
        assertEquals(testClass.testFunction136(), 136);
    }

    @Test
    void test137() {
        assertEquals(testClass.testFunction137(), 137);
    }

    @Test
    void test138() {
        assertEquals(testClass.testFunction138(), 138);
    }

    @Test
    void test139() {
        assertEquals(testClass.testFunction139(), 139);
    }

    @Test
    void test140() {
        assertEquals(testClass.testFunction140(), 140);
    }

    @Test
    void test141() {
        assertEquals(testClass.testFunction141(), 141);
    }

    @Test
    void test142() {
        assertEquals(testClass.testFunction142(), 142);
    }

    @Test
    void test143() {
        assertEquals(testClass.testFunction143(), 143);
    }

    @Test
    void test144() {
        assertEquals(testClass.testFunction144(), 144);
    }

    @Test
    void test145() {
        assertEquals(testClass.testFunction145(), 145);
    }

    @Test
    void test146() {
        assertEquals(testClass.testFunction146(), 146);
    }

    @Test
    void test147() {
        assertEquals(testClass.testFunction147(), 147);
    }

    @Test
    void test148() {
        assertEquals(testClass.testFunction148(), 148);
    }

    @Test
    void test149() {
        assertEquals(testClass.testFunction149(), 149);
    }

    @Test
    void test150() {
        assertEquals(testClass.testFunction150(), 150);
    }

    @Test
    void test151() {
        assertEquals(testClass.testFunction151(), 151);
    }

    @Test
    void test152() {
        assertEquals(testClass.testFunction152(), 152);
    }

    @Test
    void test153() {
        assertEquals(testClass.testFunction153(), 153);
    }

    @Test
    void test154() {
        assertEquals(testClass.testFunction154(), 154);
    }

    @Test
    void test155() {
        assertEquals(testClass.testFunction155(), 155);
    }

    @Test
    void test156() {
        assertEquals(testClass.testFunction156(), 156);
    }

    @Test
    void test157() {
        assertEquals(testClass.testFunction157(), 157);
    }

    @Test
    void test158() {
        assertEquals(testClass.testFunction158(), 158);
    }

    @Test
    void test159() {
        assertEquals(testClass.testFunction159(), 159);
    }

    @Test
    void test160() {
        assertEquals(testClass.testFunction160(), 160);
    }

    @Test
    void test161() {
        assertEquals(testClass.testFunction161(), 161);
    }

    @Test
    void test162() {
        assertEquals(testClass.testFunction162(), 162);
    }

    @Test
    void test163() {
        assertEquals(testClass.testFunction163(), 163);
    }

    @Test
    void test164() {
        assertEquals(testClass.testFunction164(), 164);
    }

    @Test
    void test165() {
        assertEquals(testClass.testFunction165(), 165);
    }

    @Test
    void test166() {
        assertEquals(testClass.testFunction166(), 166);
    }

    @Test
    void test167() {
        assertEquals(testClass.testFunction167(), 167);
    }

    @Test
    void test168() {
        assertEquals(testClass.testFunction168(), 168);
    }

    @Test
    void test169() {
        assertEquals(testClass.testFunction169(), 169);
    }

    @Test
    void test170() {
        assertEquals(testClass.testFunction170(), 170);
    }

    @Test
    void test171() {
        assertEquals(testClass.testFunction171(), 171);
    }

    @Test
    void test172() {
        assertEquals(testClass.testFunction172(), 172);
    }

    @Test
    void test173() {
        assertEquals(testClass.testFunction173(), 173);
    }

    @Test
    void test174() {
        assertEquals(testClass.testFunction174(), 174);
    }

    @Test
    void test175() {
        assertEquals(testClass.testFunction175(), 175);
    }

    @Test
    void test176() {
        assertEquals(testClass.testFunction176(), 176);
    }

    @Test
    void test177() {
        assertEquals(testClass.testFunction177(), 177);
    }

    @Test
    void test178() {
        assertEquals(testClass.testFunction178(), 178);
    }

    @Test
    void test179() {
        assertEquals(testClass.testFunction179(), 179);
    }

    @Test
    void test180() {
        assertEquals(testClass.testFunction180(), 180);
    }

    @Test
    void test181() {
        assertEquals(testClass.testFunction181(), 181);
    }

    @Test
    void test182() {
        assertEquals(testClass.testFunction182(), 182);
    }

    @Test
    void test183() {
        assertEquals(testClass.testFunction183(), 183);
    }

    @Test
    void test184() {
        assertEquals(testClass.testFunction184(), 184);
    }

    @Test
    void test185() {
        assertEquals(testClass.testFunction185(), 185);
    }

    @Test
    void test186() {
        assertEquals(testClass.testFunction186(), 186);
    }

    @Test
    void test187() {
        assertEquals(testClass.testFunction187(), 187);
    }

    @Test
    void test188() {
        assertEquals(testClass.testFunction188(), 188);
    }

    @Test
    void test189() {
        assertEquals(testClass.testFunction189(), 189);
    }

    @Test
    void test190() {
        assertEquals(testClass.testFunction190(), 190);
    }

    @Test
    void test191() {
        assertEquals(testClass.testFunction191(), 191);
    }

    @Test
    void test192() {
        assertEquals(testClass.testFunction192(), 192);
    }

    @Test
    void test193() {
        assertEquals(testClass.testFunction193(), 193);
    }

    @Test
    void test194() {
        assertEquals(testClass.testFunction194(), 194);
    }

    @Test
    void test195() {
        assertEquals(testClass.testFunction195(), 195);
    }

    @Test
    void test196() {
        assertEquals(testClass.testFunction196(), 196);
    }

    @Test
    void test197() {
        assertEquals(testClass.testFunction197(), 197);
    }

    @Test
    void test198() {
        assertEquals(testClass.testFunction198(), 198);
    }

    @Test
    void test199() {
        assertEquals(testClass.testFunction199(), 199);
    }

    @Test
    void test200() {
        assertEquals(testClass.testFunction200(), 200);
    }

    @Test
    void test201() {
        assertEquals(testClass.testFunction201(), 201);
    }

    @Test
    void test202() {
        assertEquals(testClass.testFunction202(), 202);
    }

    @Test
    void test203() {
        assertEquals(testClass.testFunction203(), 203);
    }

    @Test
    void test204() {
        assertEquals(testClass.testFunction204(), 204);
    }

    @Test
    void test205() {
        assertEquals(testClass.testFunction205(), 205);
    }

    @Test
    void test206() {
        assertEquals(testClass.testFunction206(), 206);
    }

    @Test
    void test207() {
        assertEquals(testClass.testFunction207(), 207);
    }

    @Test
    void test208() {
        assertEquals(testClass.testFunction208(), 208);
    }

    @Test
    void test209() {
        assertEquals(testClass.testFunction209(), 209);
    }

    @Test
    void test210() {
        assertEquals(testClass.testFunction210(), 210);
    }

    @Test
    void test211() {
        assertEquals(testClass.testFunction211(), 211);
    }

    @Test
    void test212() {
        assertEquals(testClass.testFunction212(), 212);
    }

    @Test
    void test213() {
        assertEquals(testClass.testFunction213(), 213);
    }

    @Test
    void test214() {
        assertEquals(testClass.testFunction214(), 214);
    }

    @Test
    void test215() {
        assertEquals(testClass.testFunction215(), 215);
    }

    @Test
    void test216() {
        assertEquals(testClass.testFunction216(), 216);
    }

    @Test
    void test217() {
        assertEquals(testClass.testFunction217(), 217);
    }

    @Test
    void test218() {
        assertEquals(testClass.testFunction218(), 218);
    }

    @Test
    void test219() {
        assertEquals(testClass.testFunction219(), 219);
    }

    @Test
    void test220() {
        assertEquals(testClass.testFunction220(), 220);
    }

    @Test
    void test221() {
        assertEquals(testClass.testFunction221(), 221);
    }

    @Test
    void test222() {
        assertEquals(testClass.testFunction222(), 222);
    }

    @Test
    void test223() {
        assertEquals(testClass.testFunction223(), 223);
    }

    @Test
    void test224() {
        assertEquals(testClass.testFunction224(), 224);
    }

    @Test
    void test225() {
        assertEquals(testClass.testFunction225(), 225);
    }

    @Test
    void test226() {
        assertEquals(testClass.testFunction226(), 226);
    }

    @Test
    void test227() {
        assertEquals(testClass.testFunction227(), 227);
    }

    @Test
    void test228() {
        assertEquals(testClass.testFunction228(), 228);
    }

    @Test
    void test229() {
        assertEquals(testClass.testFunction229(), 229);
    }

    @Test
    void test230() {
        assertEquals(testClass.testFunction230(), 230);
    }

    @Test
    void test231() {
        assertEquals(testClass.testFunction231(), 231);
    }

    @Test
    void test232() {
        assertEquals(testClass.testFunction232(), 232);
    }

    @Test
    void test233() {
        assertEquals(testClass.testFunction233(), 233);
    }

    @Test
    void test234() {
        assertEquals(testClass.testFunction234(), 234);
    }

    @Test
    void test235() {
        assertEquals(testClass.testFunction235(), 235);
    }

    @Test
    void test236() {
        assertEquals(testClass.testFunction236(), 236);
    }

    @Test
    void test237() {
        assertEquals(testClass.testFunction237(), 237);
    }

    @Test
    void test238() {
        assertEquals(testClass.testFunction238(), 238);
    }

    @Test
    void test239() {
        assertEquals(testClass.testFunction239(), 239);
    }

    @Test
    void test240() {
        assertEquals(testClass.testFunction240(), 240);
    }

    @Test
    void test241() {
        assertEquals(testClass.testFunction241(), 241);
    }

    @Test
    void test242() {
        assertEquals(testClass.testFunction242(), 242);
    }

    @Test
    void test243() {
        assertEquals(testClass.testFunction243(), 243);
    }

    @Test
    void test244() {
        assertEquals(testClass.testFunction244(), 244);
    }

    @Test
    void test245() {
        assertEquals(testClass.testFunction245(), 245);
    }

    @Test
    void test246() {
        assertEquals(testClass.testFunction246(), 246);
    }

    @Test
    void test247() {
        assertEquals(testClass.testFunction247(), 247);
    }

    @Test
    void test248() {
        assertEquals(testClass.testFunction248(), 248);
    }

    @Test
    void test249() {
        assertEquals(testClass.testFunction249(), 249);
    }

    @Test
    void test250() {
        assertEquals(testClass.testFunction250(), 250);
    }

    @Test
    void test251() {
        assertEquals(testClass.testFunction251(), 251);
    }

    @Test
    void test252() {
        assertEquals(testClass.testFunction252(), 252);
    }

    @Test
    void test253() {
        assertEquals(testClass.testFunction253(), 253);
    }

    @Test
    void test254() {
        assertEquals(testClass.testFunction254(), 254);
    }

    @Test
    void test255() {
        assertEquals(testClass.testFunction255(), 255);
    }

    @Test
    void test256() {
        assertEquals(testClass.testFunction256(), 256);
    }

    @Test
    void test257() {
        assertEquals(testClass.testFunction257(), 257);
    }

    @Test
    void test258() {
        assertEquals(testClass.testFunction258(), 258);
    }

    @Test
    void test259() {
        assertEquals(testClass.testFunction259(), 259);
    }

    @Test
    void test260() {
        assertEquals(testClass.testFunction260(), 260);
    }

    @Test
    void test261() {
        assertEquals(testClass.testFunction261(), 261);
    }

    @Test
    void test262() {
        assertEquals(testClass.testFunction262(), 262);
    }

    @Test
    void test263() {
        assertEquals(testClass.testFunction263(), 263);
    }

    @Test
    void test264() {
        assertEquals(testClass.testFunction264(), 264);
    }

    @Test
    void test265() {
        assertEquals(testClass.testFunction265(), 265);
    }

    @Test
    void test266() {
        assertEquals(testClass.testFunction266(), 266);
    }

    @Test
    void test267() {
        assertEquals(testClass.testFunction267(), 267);
    }

    @Test
    void test268() {
        assertEquals(testClass.testFunction268(), 268);
    }

    @Test
    void test269() {
        assertEquals(testClass.testFunction269(), 269);
    }

    @Test
    void test270() {
        assertEquals(testClass.testFunction270(), 270);
    }

    @Test
    void test271() {
        assertEquals(testClass.testFunction271(), 271);
    }

    @Test
    void test272() {
        assertEquals(testClass.testFunction272(), 272);
    }

    @Test
    void test273() {
        assertEquals(testClass.testFunction273(), 273);
    }

    @Test
    void test274() {
        assertEquals(testClass.testFunction274(), 274);
    }

    @Test
    void test275() {
        assertEquals(testClass.testFunction275(), 275);
    }

    @Test
    void test276() {
        assertEquals(testClass.testFunction276(), 276);
    }

    @Test
    void test277() {
        assertEquals(testClass.testFunction277(), 277);
    }

    @Test
    void test278() {
        assertEquals(testClass.testFunction278(), 278);
    }

    @Test
    void test279() {
        assertEquals(testClass.testFunction279(), 279);
    }

    @Test
    void test280() {
        assertEquals(testClass.testFunction280(), 280);
    }

    @Test
    void test281() {
        assertEquals(testClass.testFunction281(), 281);
    }

    @Test
    void test282() {
        assertEquals(testClass.testFunction282(), 282);
    }

    @Test
    void test283() {
        assertEquals(testClass.testFunction283(), 283);
    }

    @Test
    void test284() {
        assertEquals(testClass.testFunction284(), 284);
    }

    @Test
    void test285() {
        assertEquals(testClass.testFunction285(), 285);
    }

    @Test
    void test286() {
        assertEquals(testClass.testFunction286(), 286);
    }

    @Test
    void test287() {
        assertEquals(testClass.testFunction287(), 287);
    }

    @Test
    void test288() {
        assertEquals(testClass.testFunction288(), 288);
    }

    @Test
    void test289() {
        assertEquals(testClass.testFunction289(), 289);
    }

    @Test
    void test290() {
        assertEquals(testClass.testFunction290(), 290);
    }

    @Test
    void test291() {
        assertEquals(testClass.testFunction291(), 291);
    }

    @Test
    void test292() {
        assertEquals(testClass.testFunction292(), 292);
    }

    @Test
    void test293() {
        assertEquals(testClass.testFunction293(), 293);
    }

    @Test
    void test294() {
        assertEquals(testClass.testFunction294(), 294);
    }

    @Test
    void test295() {
        assertEquals(testClass.testFunction295(), 295);
    }

    @Test
    void test296() {
        assertEquals(testClass.testFunction296(), 296);
    }

    @Test
    void test297() {
        assertEquals(testClass.testFunction297(), 297);
    }

    @Test
    void test298() {
        assertEquals(testClass.testFunction298(), 298);
    }

    @Test
    void test299() {
        assertEquals(testClass.testFunction299(), 299);
    }

    @Test
    void test300() {
        assertEquals(testClass.testFunction300(), 300);
    }

    @Test
    void test301() {
        assertEquals(testClass.testFunction301(), 301);
    }

    @Test
    void test302() {
        assertEquals(testClass.testFunction302(), 302);
    }

    @Test
    void test303() {
        assertEquals(testClass.testFunction303(), 303);
    }

    @Test
    void test304() {
        assertEquals(testClass.testFunction304(), 304);
    }

    @Test
    void test305() {
        assertEquals(testClass.testFunction305(), 305);
    }

    @Test
    void test306() {
        assertEquals(testClass.testFunction306(), 306);
    }

    @Test
    void test307() {
        assertEquals(testClass.testFunction307(), 307);
    }

    @Test
    void test308() {
        assertEquals(testClass.testFunction308(), 308);
    }

    @Test
    void test309() {
        assertEquals(testClass.testFunction309(), 309);
    }

    @Test
    void test310() {
        assertEquals(testClass.testFunction310(), 310);
    }

    @Test
    void test311() {
        assertEquals(testClass.testFunction311(), 311);
    }

    @Test
    void test312() {
        assertEquals(testClass.testFunction312(), 312);
    }

    @Test
    void test313() {
        assertEquals(testClass.testFunction313(), 313);
    }

    @Test
    void test314() {
        assertEquals(testClass.testFunction314(), 314);
    }

    @Test
    void test315() {
        assertEquals(testClass.testFunction315(), 315);
    }

    @Test
    void test316() {
        assertEquals(testClass.testFunction316(), 316);
    }

    @Test
    void test317() {
        assertEquals(testClass.testFunction317(), 317);
    }

    @Test
    void test318() {
        assertEquals(testClass.testFunction318(), 318);
    }

    @Test
    void test319() {
        assertEquals(testClass.testFunction319(), 319);
    }

    @Test
    void test320() {
        assertEquals(testClass.testFunction320(), 320);
    }

    @Test
    void test321() {
        assertEquals(testClass.testFunction321(), 321);
    }

    @Test
    void test322() {
        assertEquals(testClass.testFunction322(), 322);
    }

    @Test
    void test323() {
        assertEquals(testClass.testFunction323(), 323);
    }

    @Test
    void test324() {
        assertEquals(testClass.testFunction324(), 324);
    }

    @Test
    void test325() {
        assertEquals(testClass.testFunction325(), 325);
    }

    @Test
    void test326() {
        assertEquals(testClass.testFunction326(), 326);
    }

    @Test
    void test327() {
        assertEquals(testClass.testFunction327(), 327);
    }

    @Test
    void test328() {
        assertEquals(testClass.testFunction328(), 328);
    }

    @Test
    void test329() {
        assertEquals(testClass.testFunction329(), 329);
    }

    @Test
    void test330() {
        assertEquals(testClass.testFunction330(), 330);
    }

    @Test
    void test331() {
        assertEquals(testClass.testFunction331(), 331);
    }

    @Test
    void test332() {
        assertEquals(testClass.testFunction332(), 332);
    }

    @Test
    void test333() {
        assertEquals(testClass.testFunction333(), 333);
    }

    @Test
    void test334() {
        assertEquals(testClass.testFunction334(), 334);
    }

    @Test
    void test335() {
        assertEquals(testClass.testFunction335(), 335);
    }

    @Test
    void test336() {
        assertEquals(testClass.testFunction336(), 336);
    }

    @Test
    void test337() {
        assertEquals(testClass.testFunction337(), 337);
    }

    @Test
    void test338() {
        assertEquals(testClass.testFunction338(), 338);
    }

    @Test
    void test339() {
        assertEquals(testClass.testFunction339(), 339);
    }

    @Test
    void test340() {
        assertEquals(testClass.testFunction340(), 340);
    }

    @Test
    void test341() {
        assertEquals(testClass.testFunction341(), 341);
    }

    @Test
    void test342() {
        assertEquals(testClass.testFunction342(), 342);
    }

    @Test
    void test343() {
        assertEquals(testClass.testFunction343(), 343);
    }

    @Test
    void test344() {
        assertEquals(testClass.testFunction344(), 344);
    }

    @Test
    void test345() {
        assertEquals(testClass.testFunction345(), 345);
    }

    @Test
    void test346() {
        assertEquals(testClass.testFunction346(), 346);
    }

    @Test
    void test347() {
        assertEquals(testClass.testFunction347(), 347);
    }

    @Test
    void test348() {
        assertEquals(testClass.testFunction348(), 348);
    }

    @Test
    void test349() {
        assertEquals(testClass.testFunction349(), 349);
    }

    @Test
    void test350() {
        assertEquals(testClass.testFunction350(), 350);
    }

    @Test
    void test351() {
        assertEquals(testClass.testFunction351(), 351);
    }

    @Test
    void test352() {
        assertEquals(testClass.testFunction352(), 352);
    }

    @Test
    void test353() {
        assertEquals(testClass.testFunction353(), 353);
    }

    @Test
    void test354() {
        assertEquals(testClass.testFunction354(), 354);
    }

    @Test
    void test355() {
        assertEquals(testClass.testFunction355(), 355);
    }

    @Test
    void test356() {
        assertEquals(testClass.testFunction356(), 356);
    }

    @Test
    void test357() {
        assertEquals(testClass.testFunction357(), 357);
    }

    @Test
    void test358() {
        assertEquals(testClass.testFunction358(), 358);
    }

    @Test
    void test359() {
        assertEquals(testClass.testFunction359(), 359);
    }

    @Test
    void test360() {
        assertEquals(testClass.testFunction360(), 360);
    }

    @Test
    void test361() {
        assertEquals(testClass.testFunction361(), 361);
    }

    @Test
    void test362() {
        assertEquals(testClass.testFunction362(), 362);
    }

    @Test
    void test363() {
        assertEquals(testClass.testFunction363(), 363);
    }

    @Test
    void test364() {
        assertEquals(testClass.testFunction364(), 364);
    }

    @Test
    void test365() {
        assertEquals(testClass.testFunction365(), 365);
    }

    @Test
    void test366() {
        assertEquals(testClass.testFunction366(), 366);
    }

    @Test
    void test367() {
        assertEquals(testClass.testFunction367(), 367);
    }

    @Test
    void test368() {
        assertEquals(testClass.testFunction368(), 368);
    }

    @Test
    void test369() {
        assertEquals(testClass.testFunction369(), 369);
    }

    @Test
    void test370() {
        assertEquals(testClass.testFunction370(), 370);
    }

    @Test
    void test371() {
        assertEquals(testClass.testFunction371(), 371);
    }

    @Test
    void test372() {
        assertEquals(testClass.testFunction372(), 372);
    }

    @Test
    void test373() {
        assertEquals(testClass.testFunction373(), 373);
    }

    @Test
    void test374() {
        assertEquals(testClass.testFunction374(), 374);
    }

    @Test
    void test375() {
        assertEquals(testClass.testFunction375(), 375);
    }

    @Test
    void test376() {
        assertEquals(testClass.testFunction376(), 376);
    }

    @Test
    void test377() {
        assertEquals(testClass.testFunction377(), 377);
    }

    @Test
    void test378() {
        assertEquals(testClass.testFunction378(), 378);
    }

    @Test
    void test379() {
        assertEquals(testClass.testFunction379(), 379);
    }

    @Test
    void test380() {
        assertEquals(testClass.testFunction380(), 380);
    }

    @Test
    void test381() {
        assertEquals(testClass.testFunction381(), 381);
    }

    @Test
    void test382() {
        assertEquals(testClass.testFunction382(), 382);
    }

    @Test
    void test383() {
        assertEquals(testClass.testFunction383(), 383);
    }

    @Test
    void test384() {
        assertEquals(testClass.testFunction384(), 384);
    }

    @Test
    void test385() {
        assertEquals(testClass.testFunction385(), 385);
    }

    @Test
    void test386() {
        assertEquals(testClass.testFunction386(), 386);
    }

    @Test
    void test387() {
        assertEquals(testClass.testFunction387(), 387);
    }

    @Test
    void test388() {
        assertEquals(testClass.testFunction388(), 388);
    }

    @Test
    void test389() {
        assertEquals(testClass.testFunction389(), 389);
    }

    @Test
    void test390() {
        assertEquals(testClass.testFunction390(), 390);
    }

    @Test
    void test391() {
        assertEquals(testClass.testFunction391(), 391);
    }

    @Test
    void test392() {
        assertEquals(testClass.testFunction392(), 392);
    }

    @Test
    void test393() {
        assertEquals(testClass.testFunction393(), 393);
    }

    @Test
    void test394() {
        assertEquals(testClass.testFunction394(), 394);
    }

    @Test
    void test395() {
        assertEquals(testClass.testFunction395(), 395);
    }

    @Test
    void test396() {
        assertEquals(testClass.testFunction396(), 396);
    }

    @Test
    void test397() {
        assertEquals(testClass.testFunction397(), 397);
    }

    @Test
    void test398() {
        assertEquals(testClass.testFunction398(), 398);
    }

    @Test
    void test399() {
        assertEquals(testClass.testFunction399(), 399);
    }

    @Test
    void test400() {
        assertEquals(testClass.testFunction400(), 400);
    }

    @Test
    void test401() {
        assertEquals(testClass.testFunction401(), 401);
    }

    @Test
    void test402() {
        assertEquals(testClass.testFunction402(), 402);
    }

    @Test
    void test403() {
        assertEquals(testClass.testFunction403(), 403);
    }

    @Test
    void test404() {
        assertEquals(testClass.testFunction404(), 404);
    }

    @Test
    void test405() {
        assertEquals(testClass.testFunction405(), 405);
    }

    @Test
    void test406() {
        assertEquals(testClass.testFunction406(), 406);
    }

    @Test
    void test407() {
        assertEquals(testClass.testFunction407(), 407);
    }

    @Test
    void test408() {
        assertEquals(testClass.testFunction408(), 408);
    }

    @Test
    void test409() {
        assertEquals(testClass.testFunction409(), 409);
    }

    @Test
    void test410() {
        assertEquals(testClass.testFunction410(), 410);
    }

    @Test
    void test411() {
        assertEquals(testClass.testFunction411(), 411);
    }

    @Test
    void test412() {
        assertEquals(testClass.testFunction412(), 412);
    }

    @Test
    void test413() {
        assertEquals(testClass.testFunction413(), 413);
    }

    @Test
    void test414() {
        assertEquals(testClass.testFunction414(), 414);
    }

    @Test
    void test415() {
        assertEquals(testClass.testFunction415(), 415);
    }

    @Test
    void test416() {
        assertEquals(testClass.testFunction416(), 416);
    }

    @Test
    void test417() {
        assertEquals(testClass.testFunction417(), 417);
    }

    @Test
    void test418() {
        assertEquals(testClass.testFunction418(), 418);
    }

    @Test
    void test419() {
        assertEquals(testClass.testFunction419(), 419);
    }

    @Test
    void test420() {
        assertEquals(testClass.testFunction420(), 420);
    }

    @Test
    void test421() {
        assertEquals(testClass.testFunction421(), 421);
    }

    @Test
    void test422() {
        assertEquals(testClass.testFunction422(), 422);
    }

    @Test
    void test423() {
        assertEquals(testClass.testFunction423(), 423);
    }

    @Test
    void test424() {
        assertEquals(testClass.testFunction424(), 424);
    }

    @Test
    void test425() {
        assertEquals(testClass.testFunction425(), 425);
    }

    @Test
    void test426() {
        assertEquals(testClass.testFunction426(), 426);
    }

    @Test
    void test427() {
        assertEquals(testClass.testFunction427(), 427);
    }

    @Test
    void test428() {
        assertEquals(testClass.testFunction428(), 428);
    }

    @Test
    void test429() {
        assertEquals(testClass.testFunction429(), 429);
    }

    @Test
    void test430() {
        assertEquals(testClass.testFunction430(), 430);
    }

    @Test
    void test431() {
        assertEquals(testClass.testFunction431(), 431);
    }

    @Test
    void test432() {
        assertEquals(testClass.testFunction432(), 432);
    }

    @Test
    void test433() {
        assertEquals(testClass.testFunction433(), 433);
    }

    @Test
    void test434() {
        assertEquals(testClass.testFunction434(), 434);
    }

    @Test
    void test435() {
        assertEquals(testClass.testFunction435(), 435);
    }

    @Test
    void test436() {
        assertEquals(testClass.testFunction436(), 436);
    }

    @Test
    void test437() {
        assertEquals(testClass.testFunction437(), 437);
    }

    @Test
    void test438() {
        assertEquals(testClass.testFunction438(), 438);
    }

    @Test
    void test439() {
        assertEquals(testClass.testFunction439(), 439);
    }

    @Test
    void test440() {
        assertEquals(testClass.testFunction440(), 440);
    }

    @Test
    void test441() {
        assertEquals(testClass.testFunction441(), 441);
    }

    @Test
    void test442() {
        assertEquals(testClass.testFunction442(), 442);
    }

    @Test
    void test443() {
        assertEquals(testClass.testFunction443(), 443);
    }

    @Test
    void test444() {
        assertEquals(testClass.testFunction444(), 444);
    }

    @Test
    void test445() {
        assertEquals(testClass.testFunction445(), 445);
    }

    @Test
    void test446() {
        assertEquals(testClass.testFunction446(), 446);
    }

    @Test
    void test447() {
        assertEquals(testClass.testFunction447(), 447);
    }

    @Test
    void test448() {
        assertEquals(testClass.testFunction448(), 448);
    }

    @Test
    void test449() {
        assertEquals(testClass.testFunction449(), 449);
    }

    @Test
    void test450() {
        assertEquals(testClass.testFunction450(), 450);
    }

    @Test
    void test451() {
        assertEquals(testClass.testFunction451(), 451);
    }

    @Test
    void test452() {
        assertEquals(testClass.testFunction452(), 452);
    }

    @Test
    void test453() {
        assertEquals(testClass.testFunction453(), 453);
    }

    @Test
    void test454() {
        assertEquals(testClass.testFunction454(), 454);
    }

    @Test
    void test455() {
        assertEquals(testClass.testFunction455(), 455);
    }

    @Test
    void test456() {
        assertEquals(testClass.testFunction456(), 456);
    }

    @Test
    void test457() {
        assertEquals(testClass.testFunction457(), 457);
    }

    @Test
    void test458() {
        assertEquals(testClass.testFunction458(), 458);
    }

    @Test
    void test459() {
        assertEquals(testClass.testFunction459(), 459);
    }

    @Test
    void test460() {
        assertEquals(testClass.testFunction460(), 460);
    }

    @Test
    void test461() {
        assertEquals(testClass.testFunction461(), 461);
    }

    @Test
    void test462() {
        assertEquals(testClass.testFunction462(), 462);
    }

    @Test
    void test463() {
        assertEquals(testClass.testFunction463(), 463);
    }

    @Test
    void test464() {
        assertEquals(testClass.testFunction464(), 464);
    }

    @Test
    void test465() {
        assertEquals(testClass.testFunction465(), 465);
    }

    @Test
    void test466() {
        assertEquals(testClass.testFunction466(), 466);
    }

    @Test
    void test467() {
        assertEquals(testClass.testFunction467(), 467);
    }

    @Test
    void test468() {
        assertEquals(testClass.testFunction468(), 468);
    }

    @Test
    void test469() {
        assertEquals(testClass.testFunction469(), 469);
    }

    @Test
    void test470() {
        assertEquals(testClass.testFunction470(), 470);
    }

    @Test
    void test471() {
        assertEquals(testClass.testFunction471(), 471);
    }

    @Test
    void test472() {
        assertEquals(testClass.testFunction472(), 472);
    }

    @Test
    void test473() {
        assertEquals(testClass.testFunction473(), 473);
    }

    @Test
    void test474() {
        assertEquals(testClass.testFunction474(), 474);
    }

    @Test
    void test475() {
        assertEquals(testClass.testFunction475(), 475);
    }

    @Test
    void test476() {
        assertEquals(testClass.testFunction476(), 476);
    }

    @Test
    void test477() {
        assertEquals(testClass.testFunction477(), 477);
    }

    @Test
    void test478() {
        assertEquals(testClass.testFunction478(), 478);
    }

    @Test
    void test479() {
        assertEquals(testClass.testFunction479(), 479);
    }

    @Test
    void test480() {
        assertEquals(testClass.testFunction480(), 480);
    }

    @Test
    void test481() {
        assertEquals(testClass.testFunction481(), 481);
    }

    @Test
    void test482() {
        assertEquals(testClass.testFunction482(), 482);
    }

    @Test
    void test483() {
        assertEquals(testClass.testFunction483(), 483);
    }

    @Test
    void test484() {
        assertEquals(testClass.testFunction484(), 484);
    }

    @Test
    void test485() {
        assertEquals(testClass.testFunction485(), 485);
    }

    @Test
    void test486() {
        assertEquals(testClass.testFunction486(), 486);
    }

    @Test
    void test487() {
        assertEquals(testClass.testFunction487(), 487);
    }

    @Test
    void test488() {
        assertEquals(testClass.testFunction488(), 488);
    }

    @Test
    void test489() {
        assertEquals(testClass.testFunction489(), 489);
    }

    @Test
    void test490() {
        assertEquals(testClass.testFunction490(), 490);
    }

    @Test
    void test491() {
        assertEquals(testClass.testFunction491(), 491);
    }

    @Test
    void test492() {
        assertEquals(testClass.testFunction492(), 492);
    }

    @Test
    void test493() {
        assertEquals(testClass.testFunction493(), 493);
    }

    @Test
    void test494() {
        assertEquals(testClass.testFunction494(), 494);
    }

    @Test
    void test495() {
        assertEquals(testClass.testFunction495(), 495);
    }

    @Test
    void test496() {
        assertEquals(testClass.testFunction496(), 496);
    }

    @Test
    void test497() {
        assertEquals(testClass.testFunction497(), 497);
    }

    @Test
    void test498() {
        assertEquals(testClass.testFunction498(), 498);
    }

    @Test
    void test499() {
        assertEquals(testClass.testFunction499(), 499);
    }

    @Test
    void test500() {
        assertEquals(testClass.testFunction500(), 500);
    }

    @Test
    void test501() {
        assertEquals(testClass.testFunction501(), 501);
    }

    @Test
    void test502() {
        assertEquals(testClass.testFunction502(), 502);
    }

    @Test
    void test503() {
        assertEquals(testClass.testFunction503(), 503);
    }

    @Test
    void test504() {
        assertEquals(testClass.testFunction504(), 504);
    }

    @Test
    void test505() {
        assertEquals(testClass.testFunction505(), 505);
    }

    @Test
    void test506() {
        assertEquals(testClass.testFunction506(), 506);
    }

    @Test
    void test507() {
        assertEquals(testClass.testFunction507(), 507);
    }

    @Test
    void test508() {
        assertEquals(testClass.testFunction508(), 508);
    }

    @Test
    void test509() {
        assertEquals(testClass.testFunction509(), 509);
    }

    @Test
    void test510() {
        assertEquals(testClass.testFunction510(), 510);
    }

    @Test
    void test511() {
        assertEquals(testClass.testFunction511(), 511);
    }

    @Test
    void test512() {
        assertEquals(testClass.testFunction512(), 512);
    }

    @Test
    void test513() {
        assertEquals(testClass.testFunction513(), 513);
    }

    @Test
    void test514() {
        assertEquals(testClass.testFunction514(), 514);
    }

    @Test
    void test515() {
        assertEquals(testClass.testFunction515(), 515);
    }

    @Test
    void test516() {
        assertEquals(testClass.testFunction516(), 516);
    }

    @Test
    void test517() {
        assertEquals(testClass.testFunction517(), 517);
    }

    @Test
    void test518() {
        assertEquals(testClass.testFunction518(), 518);
    }

    @Test
    void test519() {
        assertEquals(testClass.testFunction519(), 519);
    }

    @Test
    void test520() {
        assertEquals(testClass.testFunction520(), 520);
    }

    @Test
    void test521() {
        assertEquals(testClass.testFunction521(), 521);
    }

    @Test
    void test522() {
        assertEquals(testClass.testFunction522(), 522);
    }

    @Test
    void test523() {
        assertEquals(testClass.testFunction523(), 523);
    }

    @Test
    void test524() {
        assertEquals(testClass.testFunction524(), 524);
    }

    @Test
    void test525() {
        assertEquals(testClass.testFunction525(), 525);
    }

    @Test
    void test526() {
        assertEquals(testClass.testFunction526(), 526);
    }

    @Test
    void test527() {
        assertEquals(testClass.testFunction527(), 527);
    }

    @Test
    void test528() {
        assertEquals(testClass.testFunction528(), 528);
    }

    @Test
    void test529() {
        assertEquals(testClass.testFunction529(), 529);
    }

    @Test
    void test530() {
        assertEquals(testClass.testFunction530(), 530);
    }

    @Test
    void test531() {
        assertEquals(testClass.testFunction531(), 531);
    }

    @Test
    void test532() {
        assertEquals(testClass.testFunction532(), 532);
    }

    @Test
    void test533() {
        assertEquals(testClass.testFunction533(), 533);
    }

    @Test
    void test534() {
        assertEquals(testClass.testFunction534(), 534);
    }

    @Test
    void test535() {
        assertEquals(testClass.testFunction535(), 535);
    }

    @Test
    void test536() {
        assertEquals(testClass.testFunction536(), 536);
    }

    @Test
    void test537() {
        assertEquals(testClass.testFunction537(), 537);
    }

    @Test
    void test538() {
        assertEquals(testClass.testFunction538(), 538);
    }

    @Test
    void test539() {
        assertEquals(testClass.testFunction539(), 539);
    }

    @Test
    void test540() {
        assertEquals(testClass.testFunction540(), 540);
    }

    @Test
    void test541() {
        assertEquals(testClass.testFunction541(), 541);
    }

    @Test
    void test542() {
        assertEquals(testClass.testFunction542(), 542);
    }

    @Test
    void test543() {
        assertEquals(testClass.testFunction543(), 543);
    }

    @Test
    void test544() {
        assertEquals(testClass.testFunction544(), 544);
    }

    @Test
    void test545() {
        assertEquals(testClass.testFunction545(), 545);
    }

    @Test
    void test546() {
        assertEquals(testClass.testFunction546(), 546);
    }

    @Test
    void test547() {
        assertEquals(testClass.testFunction547(), 547);
    }

    @Test
    void test548() {
        assertEquals(testClass.testFunction548(), 548);
    }

    @Test
    void test549() {
        assertEquals(testClass.testFunction549(), 549);
    }

    @Test
    void test550() {
        assertEquals(testClass.testFunction550(), 550);
    }

    @Test
    void test551() {
        assertEquals(testClass.testFunction551(), 551);
    }

    @Test
    void test552() {
        assertEquals(testClass.testFunction552(), 552);
    }

    @Test
    void test553() {
        assertEquals(testClass.testFunction553(), 553);
    }

    @Test
    void test554() {
        assertEquals(testClass.testFunction554(), 554);
    }

    @Test
    void test555() {
        assertEquals(testClass.testFunction555(), 555);
    }

    @Test
    void test556() {
        assertEquals(testClass.testFunction556(), 556);
    }

    @Test
    void test557() {
        assertEquals(testClass.testFunction557(), 557);
    }

    @Test
    void test558() {
        assertEquals(testClass.testFunction558(), 558);
    }

    @Test
    void test559() {
        assertEquals(testClass.testFunction559(), 559);
    }

    @Test
    void test560() {
        assertEquals(testClass.testFunction560(), 560);
    }

    @Test
    void test561() {
        assertEquals(testClass.testFunction561(), 561);
    }

    @Test
    void test562() {
        assertEquals(testClass.testFunction562(), 562);
    }

    @Test
    void test563() {
        assertEquals(testClass.testFunction563(), 563);
    }

    @Test
    void test564() {
        assertEquals(testClass.testFunction564(), 564);
    }

    @Test
    void test565() {
        assertEquals(testClass.testFunction565(), 565);
    }

    @Test
    void test566() {
        assertEquals(testClass.testFunction566(), 566);
    }

    @Test
    void test567() {
        assertEquals(testClass.testFunction567(), 567);
    }

    @Test
    void test568() {
        assertEquals(testClass.testFunction568(), 568);
    }

    @Test
    void test569() {
        assertEquals(testClass.testFunction569(), 569);
    }

    @Test
    void test570() {
        assertEquals(testClass.testFunction570(), 570);
    }

    @Test
    void test571() {
        assertEquals(testClass.testFunction571(), 571);
    }

    @Test
    void test572() {
        assertEquals(testClass.testFunction572(), 572);
    }

    @Test
    void test573() {
        assertEquals(testClass.testFunction573(), 573);
    }

    @Test
    void test574() {
        assertEquals(testClass.testFunction574(), 574);
    }

    @Test
    void test575() {
        assertEquals(testClass.testFunction575(), 575);
    }

    @Test
    void test576() {
        assertEquals(testClass.testFunction576(), 576);
    }

    @Test
    void test577() {
        assertEquals(testClass.testFunction577(), 577);
    }

    @Test
    void test578() {
        assertEquals(testClass.testFunction578(), 578);
    }

    @Test
    void test579() {
        assertEquals(testClass.testFunction579(), 579);
    }

    @Test
    void test580() {
        assertEquals(testClass.testFunction580(), 580);
    }

    @Test
    void test581() {
        assertEquals(testClass.testFunction581(), 581);
    }

    @Test
    void test582() {
        assertEquals(testClass.testFunction582(), 582);
    }

    @Test
    void test583() {
        assertEquals(testClass.testFunction583(), 583);
    }

    @Test
    void test584() {
        assertEquals(testClass.testFunction584(), 584);
    }

    @Test
    void test585() {
        assertEquals(testClass.testFunction585(), 585);
    }

    @Test
    void test586() {
        assertEquals(testClass.testFunction586(), 586);
    }

    @Test
    void test587() {
        assertEquals(testClass.testFunction587(), 587);
    }

    @Test
    void test588() {
        assertEquals(testClass.testFunction588(), 588);
    }

    @Test
    void test589() {
        assertEquals(testClass.testFunction589(), 589);
    }

    @Test
    void test590() {
        assertEquals(testClass.testFunction590(), 590);
    }

    @Test
    void test591() {
        assertEquals(testClass.testFunction591(), 591);
    }

    @Test
    void test592() {
        assertEquals(testClass.testFunction592(), 592);
    }

    @Test
    void test593() {
        assertEquals(testClass.testFunction593(), 593);
    }

    @Test
    void test594() {
        assertEquals(testClass.testFunction594(), 594);
    }

    @Test
    void test595() {
        assertEquals(testClass.testFunction595(), 595);
    }

    @Test
    void test596() {
        assertEquals(testClass.testFunction596(), 596);
    }

    @Test
    void test597() {
        assertEquals(testClass.testFunction597(), 597);
    }

    @Test
    void test598() {
        assertEquals(testClass.testFunction598(), 598);
    }

    @Test
    void test599() {
        assertEquals(testClass.testFunction599(), 599);
    }

    @Test
    void test600() {
        assertEquals(testClass.testFunction600(), 600);
    }

    @Test
    void test601() {
        assertEquals(testClass.testFunction601(), 601);
    }

    @Test
    void test602() {
        assertEquals(testClass.testFunction602(), 602);
    }

    @Test
    void test603() {
        assertEquals(testClass.testFunction603(), 603);
    }

    @Test
    void test604() {
        assertEquals(testClass.testFunction604(), 604);
    }

    @Test
    void test605() {
        assertEquals(testClass.testFunction605(), 605);
    }

    @Test
    void test606() {
        assertEquals(testClass.testFunction606(), 606);
    }

    @Test
    void test607() {
        assertEquals(testClass.testFunction607(), 607);
    }

    @Test
    void test608() {
        assertEquals(testClass.testFunction608(), 608);
    }

    @Test
    void test609() {
        assertEquals(testClass.testFunction609(), 609);
    }

    @Test
    void test610() {
        assertEquals(testClass.testFunction610(), 610);
    }

    @Test
    void test611() {
        assertEquals(testClass.testFunction611(), 611);
    }

    @Test
    void test612() {
        assertEquals(testClass.testFunction612(), 612);
    }

    @Test
    void test613() {
        assertEquals(testClass.testFunction613(), 613);
    }

    @Test
    void test614() {
        assertEquals(testClass.testFunction614(), 614);
    }

    @Test
    void test615() {
        assertEquals(testClass.testFunction615(), 615);
    }

    @Test
    void test616() {
        assertEquals(testClass.testFunction616(), 616);
    }

    @Test
    void test617() {
        assertEquals(testClass.testFunction617(), 617);
    }

    @Test
    void test618() {
        assertEquals(testClass.testFunction618(), 618);
    }

    @Test
    void test619() {
        assertEquals(testClass.testFunction619(), 619);
    }

    @Test
    void test620() {
        assertEquals(testClass.testFunction620(), 620);
    }

    @Test
    void test621() {
        assertEquals(testClass.testFunction621(), 621);
    }

    @Test
    void test622() {
        assertEquals(testClass.testFunction622(), 622);
    }

    @Test
    void test623() {
        assertEquals(testClass.testFunction623(), 623);
    }

    @Test
    void test624() {
        assertEquals(testClass.testFunction624(), 624);
    }

    @Test
    void test625() {
        assertEquals(testClass.testFunction625(), 625);
    }

    @Test
    void test626() {
        assertEquals(testClass.testFunction626(), 626);
    }

    @Test
    void test627() {
        assertEquals(testClass.testFunction627(), 627);
    }

    @Test
    void test628() {
        assertEquals(testClass.testFunction628(), 628);
    }

    @Test
    void test629() {
        assertEquals(testClass.testFunction629(), 629);
    }

    @Test
    void test630() {
        assertEquals(testClass.testFunction630(), 630);
    }

    @Test
    void test631() {
        assertEquals(testClass.testFunction631(), 631);
    }

    @Test
    void test632() {
        assertEquals(testClass.testFunction632(), 632);
    }

    @Test
    void test633() {
        assertEquals(testClass.testFunction633(), 633);
    }

    @Test
    void test634() {
        assertEquals(testClass.testFunction634(), 634);
    }

    @Test
    void test635() {
        assertEquals(testClass.testFunction635(), 635);
    }

    @Test
    void test636() {
        assertEquals(testClass.testFunction636(), 636);
    }

    @Test
    void test637() {
        assertEquals(testClass.testFunction637(), 637);
    }

    @Test
    void test638() {
        assertEquals(testClass.testFunction638(), 638);
    }

    @Test
    void test639() {
        assertEquals(testClass.testFunction639(), 639);
    }

    @Test
    void test640() {
        assertEquals(testClass.testFunction640(), 640);
    }

    @Test
    void test641() {
        assertEquals(testClass.testFunction641(), 641);
    }

    @Test
    void test642() {
        assertEquals(testClass.testFunction642(), 642);
    }

    @Test
    void test643() {
        assertEquals(testClass.testFunction643(), 643);
    }

    @Test
    void test644() {
        assertEquals(testClass.testFunction644(), 644);
    }

    @Test
    void test645() {
        assertEquals(testClass.testFunction645(), 645);
    }

    @Test
    void test646() {
        assertEquals(testClass.testFunction646(), 646);
    }

    @Test
    void test647() {
        assertEquals(testClass.testFunction647(), 647);
    }

    @Test
    void test648() {
        assertEquals(testClass.testFunction648(), 648);
    }

    @Test
    void test649() {
        assertEquals(testClass.testFunction649(), 649);
    }

    @Test
    void test650() {
        assertEquals(testClass.testFunction650(), 650);
    }

    @Test
    void test651() {
        assertEquals(testClass.testFunction651(), 651);
    }

    @Test
    void test652() {
        assertEquals(testClass.testFunction652(), 652);
    }

    @Test
    void test653() {
        assertEquals(testClass.testFunction653(), 653);
    }

    @Test
    void test654() {
        assertEquals(testClass.testFunction654(), 654);
    }

    @Test
    void test655() {
        assertEquals(testClass.testFunction655(), 655);
    }

    @Test
    void test656() {
        assertEquals(testClass.testFunction656(), 656);
    }

    @Test
    void test657() {
        assertEquals(testClass.testFunction657(), 657);
    }

    @Test
    void test658() {
        assertEquals(testClass.testFunction658(), 658);
    }

    @Test
    void test659() {
        assertEquals(testClass.testFunction659(), 659);
    }

    @Test
    void test660() {
        assertEquals(testClass.testFunction660(), 660);
    }

    @Test
    void test661() {
        assertEquals(testClass.testFunction661(), 661);
    }

    @Test
    void test662() {
        assertEquals(testClass.testFunction662(), 662);
    }

    @Test
    void test663() {
        assertEquals(testClass.testFunction663(), 663);
    }

    @Test
    void test664() {
        assertEquals(testClass.testFunction664(), 664);
    }

    @Test
    void test665() {
        assertEquals(testClass.testFunction665(), 665);
    }

    @Test
    void test666() {
        assertEquals(testClass.testFunction666(), 666);
    }

    @Test
    void test667() {
        assertEquals(testClass.testFunction667(), 667);
    }

    @Test
    void test668() {
        assertEquals(testClass.testFunction668(), 668);
    }

    @Test
    void test669() {
        assertEquals(testClass.testFunction669(), 669);
    }

    @Test
    void test670() {
        assertEquals(testClass.testFunction670(), 670);
    }

    @Test
    void test671() {
        assertEquals(testClass.testFunction671(), 671);
    }

    @Test
    void test672() {
        assertEquals(testClass.testFunction672(), 672);
    }

    @Test
    void test673() {
        assertEquals(testClass.testFunction673(), 673);
    }

    @Test
    void test674() {
        assertEquals(testClass.testFunction674(), 674);
    }

    @Test
    void test675() {
        assertEquals(testClass.testFunction675(), 675);
    }

    @Test
    void test676() {
        assertEquals(testClass.testFunction676(), 676);
    }

    @Test
    void test677() {
        assertEquals(testClass.testFunction677(), 677);
    }

    @Test
    void test678() {
        assertEquals(testClass.testFunction678(), 678);
    }

    @Test
    void test679() {
        assertEquals(testClass.testFunction679(), 679);
    }

    @Test
    void test680() {
        assertEquals(testClass.testFunction680(), 680);
    }

    @Test
    void test681() {
        assertEquals(testClass.testFunction681(), 681);
    }

    @Test
    void test682() {
        assertEquals(testClass.testFunction682(), 682);
    }

    @Test
    void test683() {
        assertEquals(testClass.testFunction683(), 683);
    }

    @Test
    void test684() {
        assertEquals(testClass.testFunction684(), 684);
    }

    @Test
    void test685() {
        assertEquals(testClass.testFunction685(), 685);
    }

    @Test
    void test686() {
        assertEquals(testClass.testFunction686(), 686);
    }

    @Test
    void test687() {
        assertEquals(testClass.testFunction687(), 687);
    }

    @Test
    void test688() {
        assertEquals(testClass.testFunction688(), 688);
    }

    @Test
    void test689() {
        assertEquals(testClass.testFunction689(), 689);
    }

    @Test
    void test690() {
        assertEquals(testClass.testFunction690(), 690);
    }

    @Test
    void test691() {
        assertEquals(testClass.testFunction691(), 691);
    }

    @Test
    void test692() {
        assertEquals(testClass.testFunction692(), 692);
    }

    @Test
    void test693() {
        assertEquals(testClass.testFunction693(), 693);
    }

    @Test
    void test694() {
        assertEquals(testClass.testFunction694(), 694);
    }

    @Test
    void test695() {
        assertEquals(testClass.testFunction695(), 695);
    }

    @Test
    void test696() {
        assertEquals(testClass.testFunction696(), 696);
    }

    @Test
    void test697() {
        assertEquals(testClass.testFunction697(), 697);
    }

    @Test
    void test698() {
        assertEquals(testClass.testFunction698(), 698);
    }

    @Test
    void test699() {
        assertEquals(testClass.testFunction699(), 699);
    }

    @Test
    void test700() {
        assertEquals(testClass.testFunction700(), 700);
    }

    @Test
    void test701() {
        assertEquals(testClass.testFunction701(), 701);
    }

    @Test
    void test702() {
        assertEquals(testClass.testFunction702(), 702);
    }

    @Test
    void test703() {
        assertEquals(testClass.testFunction703(), 703);
    }

    @Test
    void test704() {
        assertEquals(testClass.testFunction704(), 704);
    }

    @Test
    void test705() {
        assertEquals(testClass.testFunction705(), 705);
    }

    @Test
    void test706() {
        assertEquals(testClass.testFunction706(), 706);
    }

    @Test
    void test707() {
        assertEquals(testClass.testFunction707(), 707);
    }

    @Test
    void test708() {
        assertEquals(testClass.testFunction708(), 708);
    }

    @Test
    void test709() {
        assertEquals(testClass.testFunction709(), 709);
    }

    @Test
    void test710() {
        assertEquals(testClass.testFunction710(), 710);
    }

    @Test
    void test711() {
        assertEquals(testClass.testFunction711(), 711);
    }

    @Test
    void test712() {
        assertEquals(testClass.testFunction712(), 712);
    }

    @Test
    void test713() {
        assertEquals(testClass.testFunction713(), 713);
    }

    @Test
    void test714() {
        assertEquals(testClass.testFunction714(), 714);
    }

    @Test
    void test715() {
        assertEquals(testClass.testFunction715(), 715);
    }

    @Test
    void test716() {
        assertEquals(testClass.testFunction716(), 716);
    }

    @Test
    void test717() {
        assertEquals(testClass.testFunction717(), 717);
    }

    @Test
    void test718() {
        assertEquals(testClass.testFunction718(), 718);
    }

    @Test
    void test719() {
        assertEquals(testClass.testFunction719(), 719);
    }

    @Test
    void test720() {
        assertEquals(testClass.testFunction720(), 720);
    }

    @Test
    void test721() {
        assertEquals(testClass.testFunction721(), 721);
    }

    @Test
    void test722() {
        assertEquals(testClass.testFunction722(), 722);
    }

    @Test
    void test723() {
        assertEquals(testClass.testFunction723(), 723);
    }

    @Test
    void test724() {
        assertEquals(testClass.testFunction724(), 724);
    }

    @Test
    void test725() {
        assertEquals(testClass.testFunction725(), 725);
    }

    @Test
    void test726() {
        assertEquals(testClass.testFunction726(), 726);
    }

    @Test
    void test727() {
        assertEquals(testClass.testFunction727(), 727);
    }

    @Test
    void test728() {
        assertEquals(testClass.testFunction728(), 728);
    }

    @Test
    void test729() {
        assertEquals(testClass.testFunction729(), 729);
    }

    @Test
    void test730() {
        assertEquals(testClass.testFunction730(), 730);
    }

    @Test
    void test731() {
        assertEquals(testClass.testFunction731(), 731);
    }

    @Test
    void test732() {
        assertEquals(testClass.testFunction732(), 732);
    }

    @Test
    void test733() {
        assertEquals(testClass.testFunction733(), 733);
    }

    @Test
    void test734() {
        assertEquals(testClass.testFunction734(), 734);
    }

    @Test
    void test735() {
        assertEquals(testClass.testFunction735(), 735);
    }

    @Test
    void test736() {
        assertEquals(testClass.testFunction736(), 736);
    }

    @Test
    void test737() {
        assertEquals(testClass.testFunction737(), 737);
    }

    @Test
    void test738() {
        assertEquals(testClass.testFunction738(), 738);
    }

    @Test
    void test739() {
        assertEquals(testClass.testFunction739(), 739);
    }

    @Test
    void test740() {
        assertEquals(testClass.testFunction740(), 740);
    }

    @Test
    void test741() {
        assertEquals(testClass.testFunction741(), 741);
    }

    @Test
    void test742() {
        assertEquals(testClass.testFunction742(), 742);
    }

    @Test
    void test743() {
        assertEquals(testClass.testFunction743(), 743);
    }

    @Test
    void test744() {
        assertEquals(testClass.testFunction744(), 744);
    }

    @Test
    void test745() {
        assertEquals(testClass.testFunction745(), 745);
    }

    @Test
    void test746() {
        assertEquals(testClass.testFunction746(), 746);
    }

    @Test
    void test747() {
        assertEquals(testClass.testFunction747(), 747);
    }

    @Test
    void test748() {
        assertEquals(testClass.testFunction748(), 748);
    }

    @Test
    void test749() {
        assertEquals(testClass.testFunction749(), 749);
    }

    @Test
    void test750() {
        assertEquals(testClass.testFunction750(), 750);
    }

    @Test
    void test751() {
        assertEquals(testClass.testFunction751(), 751);
    }

    @Test
    void test752() {
        assertEquals(testClass.testFunction752(), 752);
    }

    @Test
    void test753() {
        assertEquals(testClass.testFunction753(), 753);
    }

    @Test
    void test754() {
        assertEquals(testClass.testFunction754(), 754);
    }

    @Test
    void test755() {
        assertEquals(testClass.testFunction755(), 755);
    }

    @Test
    void test756() {
        assertEquals(testClass.testFunction756(), 756);
    }

    @Test
    void test757() {
        assertEquals(testClass.testFunction757(), 757);
    }

    @Test
    void test758() {
        assertEquals(testClass.testFunction758(), 758);
    }

    @Test
    void test759() {
        assertEquals(testClass.testFunction759(), 759);
    }

    @Test
    void test760() {
        assertEquals(testClass.testFunction760(), 760);
    }

    @Test
    void test761() {
        assertEquals(testClass.testFunction761(), 761);
    }

    @Test
    void test762() {
        assertEquals(testClass.testFunction762(), 762);
    }

    @Test
    void test763() {
        assertEquals(testClass.testFunction763(), 763);
    }

    @Test
    void test764() {
        assertEquals(testClass.testFunction764(), 764);
    }

    @Test
    void test765() {
        assertEquals(testClass.testFunction765(), 765);
    }

    @Test
    void test766() {
        assertEquals(testClass.testFunction766(), 766);
    }

    @Test
    void test767() {
        assertEquals(testClass.testFunction767(), 767);
    }

    @Test
    void test768() {
        assertEquals(testClass.testFunction768(), 768);
    }

    @Test
    void test769() {
        assertEquals(testClass.testFunction769(), 769);
    }

    @Test
    void test770() {
        assertEquals(testClass.testFunction770(), 770);
    }

    @Test
    void test771() {
        assertEquals(testClass.testFunction771(), 771);
    }

    @Test
    void test772() {
        assertEquals(testClass.testFunction772(), 772);
    }

    @Test
    void test773() {
        assertEquals(testClass.testFunction773(), 773);
    }

    @Test
    void test774() {
        assertEquals(testClass.testFunction774(), 774);
    }

    @Test
    void test775() {
        assertEquals(testClass.testFunction775(), 775);
    }

    @Test
    void test776() {
        assertEquals(testClass.testFunction776(), 776);
    }

    @Test
    void test777() {
        assertEquals(testClass.testFunction777(), 777);
    }

    @Test
    void test778() {
        assertEquals(testClass.testFunction778(), 778);
    }

    @Test
    void test779() {
        assertEquals(testClass.testFunction779(), 779);
    }

    @Test
    void test780() {
        assertEquals(testClass.testFunction780(), 780);
    }

    @Test
    void test781() {
        assertEquals(testClass.testFunction781(), 781);
    }

    @Test
    void test782() {
        assertEquals(testClass.testFunction782(), 782);
    }

    @Test
    void test783() {
        assertEquals(testClass.testFunction783(), 783);
    }

    @Test
    void test784() {
        assertEquals(testClass.testFunction784(), 784);
    }

    @Test
    void test785() {
        assertEquals(testClass.testFunction785(), 785);
    }

    @Test
    void test786() {
        assertEquals(testClass.testFunction786(), 786);
    }

    @Test
    void test787() {
        assertEquals(testClass.testFunction787(), 787);
    }

    @Test
    void test788() {
        assertEquals(testClass.testFunction788(), 788);
    }

    @Test
    void test789() {
        assertEquals(testClass.testFunction789(), 789);
    }

    @Test
    void test790() {
        assertEquals(testClass.testFunction790(), 790);
    }

    @Test
    void test791() {
        assertEquals(testClass.testFunction791(), 791);
    }

    @Test
    void test792() {
        assertEquals(testClass.testFunction792(), 792);
    }

    @Test
    void test793() {
        assertEquals(testClass.testFunction793(), 793);
    }

    @Test
    void test794() {
        assertEquals(testClass.testFunction794(), 794);
    }

    @Test
    void test795() {
        assertEquals(testClass.testFunction795(), 795);
    }

    @Test
    void test796() {
        assertEquals(testClass.testFunction796(), 796);
    }

    @Test
    void test797() {
        assertEquals(testClass.testFunction797(), 797);
    }

    @Test
    void test798() {
        assertEquals(testClass.testFunction798(), 798);
    }

    @Test
    void test799() {
        assertEquals(testClass.testFunction799(), 799);
    }

    @Test
    void test800() {
        assertEquals(testClass.testFunction800(), 800);
    }

    @Test
    void test801() {
        assertEquals(testClass.testFunction801(), 801);
    }

    @Test
    void test802() {
        assertEquals(testClass.testFunction802(), 802);
    }

    @Test
    void test803() {
        assertEquals(testClass.testFunction803(), 803);
    }

    @Test
    void test804() {
        assertEquals(testClass.testFunction804(), 804);
    }

    @Test
    void test805() {
        assertEquals(testClass.testFunction805(), 805);
    }

    @Test
    void test806() {
        assertEquals(testClass.testFunction806(), 806);
    }

    @Test
    void test807() {
        assertEquals(testClass.testFunction807(), 807);
    }

    @Test
    void test808() {
        assertEquals(testClass.testFunction808(), 808);
    }

    @Test
    void test809() {
        assertEquals(testClass.testFunction809(), 809);
    }

    @Test
    void test810() {
        assertEquals(testClass.testFunction810(), 810);
    }

    @Test
    void test811() {
        assertEquals(testClass.testFunction811(), 811);
    }

    @Test
    void test812() {
        assertEquals(testClass.testFunction812(), 812);
    }

    @Test
    void test813() {
        assertEquals(testClass.testFunction813(), 813);
    }

    @Test
    void test814() {
        assertEquals(testClass.testFunction814(), 814);
    }

    @Test
    void test815() {
        assertEquals(testClass.testFunction815(), 815);
    }

    @Test
    void test816() {
        assertEquals(testClass.testFunction816(), 816);
    }

    @Test
    void test817() {
        assertEquals(testClass.testFunction817(), 817);
    }

    @Test
    void test818() {
        assertEquals(testClass.testFunction818(), 818);
    }

    @Test
    void test819() {
        assertEquals(testClass.testFunction819(), 819);
    }

    @Test
    void test820() {
        assertEquals(testClass.testFunction820(), 820);
    }

    @Test
    void test821() {
        assertEquals(testClass.testFunction821(), 821);
    }

    @Test
    void test822() {
        assertEquals(testClass.testFunction822(), 822);
    }

    @Test
    void test823() {
        assertEquals(testClass.testFunction823(), 823);
    }

    @Test
    void test824() {
        assertEquals(testClass.testFunction824(), 824);
    }

    @Test
    void test825() {
        assertEquals(testClass.testFunction825(), 825);
    }

    @Test
    void test826() {
        assertEquals(testClass.testFunction826(), 826);
    }

    @Test
    void test827() {
        assertEquals(testClass.testFunction827(), 827);
    }

    @Test
    void test828() {
        assertEquals(testClass.testFunction828(), 828);
    }

    @Test
    void test829() {
        assertEquals(testClass.testFunction829(), 829);
    }

    @Test
    void test830() {
        assertEquals(testClass.testFunction830(), 830);
    }

    @Test
    void test831() {
        assertEquals(testClass.testFunction831(), 831);
    }

    @Test
    void test832() {
        assertEquals(testClass.testFunction832(), 832);
    }

    @Test
    void test833() {
        assertEquals(testClass.testFunction833(), 833);
    }

    @Test
    void test834() {
        assertEquals(testClass.testFunction834(), 834);
    }

    @Test
    void test835() {
        assertEquals(testClass.testFunction835(), 835);
    }

    @Test
    void test836() {
        assertEquals(testClass.testFunction836(), 836);
    }

    @Test
    void test837() {
        assertEquals(testClass.testFunction837(), 837);
    }

    @Test
    void test838() {
        assertEquals(testClass.testFunction838(), 838);
    }

    @Test
    void test839() {
        assertEquals(testClass.testFunction839(), 839);
    }

    @Test
    void test840() {
        assertEquals(testClass.testFunction840(), 840);
    }

    @Test
    void test841() {
        assertEquals(testClass.testFunction841(), 841);
    }

    @Test
    void test842() {
        assertEquals(testClass.testFunction842(), 842);
    }

    @Test
    void test843() {
        assertEquals(testClass.testFunction843(), 843);
    }

    @Test
    void test844() {
        assertEquals(testClass.testFunction844(), 844);
    }

    @Test
    void test845() {
        assertEquals(testClass.testFunction845(), 845);
    }

    @Test
    void test846() {
        assertEquals(testClass.testFunction846(), 846);
    }

    @Test
    void test847() {
        assertEquals(testClass.testFunction847(), 847);
    }

    @Test
    void test848() {
        assertEquals(testClass.testFunction848(), 848);
    }

    @Test
    void test849() {
        assertEquals(testClass.testFunction849(), 849);
    }

    @Test
    void test850() {
        assertEquals(testClass.testFunction850(), 850);
    }

    @Test
    void test851() {
        assertEquals(testClass.testFunction851(), 851);
    }

    @Test
    void test852() {
        assertEquals(testClass.testFunction852(), 852);
    }

    @Test
    void test853() {
        assertEquals(testClass.testFunction853(), 853);
    }

    @Test
    void test854() {
        assertEquals(testClass.testFunction854(), 854);
    }

    @Test
    void test855() {
        assertEquals(testClass.testFunction855(), 855);
    }

    @Test
    void test856() {
        assertEquals(testClass.testFunction856(), 856);
    }

    @Test
    void test857() {
        assertEquals(testClass.testFunction857(), 857);
    }

    @Test
    void test858() {
        assertEquals(testClass.testFunction858(), 858);
    }

    @Test
    void test859() {
        assertEquals(testClass.testFunction859(), 859);
    }

    @Test
    void test860() {
        assertEquals(testClass.testFunction860(), 860);
    }

    @Test
    void test861() {
        assertEquals(testClass.testFunction861(), 861);
    }

    @Test
    void test862() {
        assertEquals(testClass.testFunction862(), 862);
    }

    @Test
    void test863() {
        assertEquals(testClass.testFunction863(), 863);
    }

    @Test
    void test864() {
        assertEquals(testClass.testFunction864(), 864);
    }

    @Test
    void test865() {
        assertEquals(testClass.testFunction865(), 865);
    }

    @Test
    void test866() {
        assertEquals(testClass.testFunction866(), 866);
    }

    @Test
    void test867() {
        assertEquals(testClass.testFunction867(), 867);
    }

    @Test
    void test868() {
        assertEquals(testClass.testFunction868(), 868);
    }

    @Test
    void test869() {
        assertEquals(testClass.testFunction869(), 869);
    }

    @Test
    void test870() {
        assertEquals(testClass.testFunction870(), 870);
    }

    @Test
    void test871() {
        assertEquals(testClass.testFunction871(), 871);
    }

    @Test
    void test872() {
        assertEquals(testClass.testFunction872(), 872);
    }

    @Test
    void test873() {
        assertEquals(testClass.testFunction873(), 873);
    }

    @Test
    void test874() {
        assertEquals(testClass.testFunction874(), 874);
    }

    @Test
    void test875() {
        assertEquals(testClass.testFunction875(), 875);
    }

    @Test
    void test876() {
        assertEquals(testClass.testFunction876(), 876);
    }

    @Test
    void test877() {
        assertEquals(testClass.testFunction877(), 877);
    }

    @Test
    void test878() {
        assertEquals(testClass.testFunction878(), 878);
    }

    @Test
    void test879() {
        assertEquals(testClass.testFunction879(), 879);
    }

    @Test
    void test880() {
        assertEquals(testClass.testFunction880(), 880);
    }

    @Test
    void test881() {
        assertEquals(testClass.testFunction881(), 881);
    }

    @Test
    void test882() {
        assertEquals(testClass.testFunction882(), 882);
    }

    @Test
    void test883() {
        assertEquals(testClass.testFunction883(), 883);
    }

    @Test
    void test884() {
        assertEquals(testClass.testFunction884(), 884);
    }

    @Test
    void test885() {
        assertEquals(testClass.testFunction885(), 885);
    }

    @Test
    void test886() {
        assertEquals(testClass.testFunction886(), 886);
    }

    @Test
    void test887() {
        assertEquals(testClass.testFunction887(), 887);
    }

    @Test
    void test888() {
        assertEquals(testClass.testFunction888(), 888);
    }

    @Test
    void test889() {
        assertEquals(testClass.testFunction889(), 889);
    }

    @Test
    void test890() {
        assertEquals(testClass.testFunction890(), 890);
    }

    @Test
    void test891() {
        assertEquals(testClass.testFunction891(), 891);
    }

    @Test
    void test892() {
        assertEquals(testClass.testFunction892(), 892);
    }

    @Test
    void test893() {
        assertEquals(testClass.testFunction893(), 893);
    }

    @Test
    void test894() {
        assertEquals(testClass.testFunction894(), 894);
    }

    @Test
    void test895() {
        assertEquals(testClass.testFunction895(), 895);
    }

    @Test
    void test896() {
        assertEquals(testClass.testFunction896(), 896);
    }

    @Test
    void test897() {
        assertEquals(testClass.testFunction897(), 897);
    }

    @Test
    void test898() {
        assertEquals(testClass.testFunction898(), 898);
    }

    @Test
    void test899() {
        assertEquals(testClass.testFunction899(), 899);
    }

    @Test
    void test900() {
        assertEquals(testClass.testFunction900(), 900);
    }


    @Test
    void test901() {
        assertEquals(testClass.testFunction901(), 901);
    }

    @Test
    void test902() {
        assertEquals(testClass.testFunction902(), 902);
    }

    @Test
    void test903() {
        assertEquals(testClass.testFunction903(), 903);
    }

    @Test
    void test904() {
        assertEquals(testClass.testFunction904(), 904);
    }

    @Test
    void test905() {
        assertEquals(testClass.testFunction905(), 905);
    }

    @Test
    void test906() {
        assertEquals(testClass.testFunction906(), 906);
    }

    @Test
    void test907() {
        assertEquals(testClass.testFunction907(), 907);
    }

    @Test
    void test908() {
        assertEquals(testClass.testFunction908(), 908);
    }

    @Test
    void test909() {
        assertEquals(testClass.testFunction909(), 909);
    }

    @Test
    void test910() {
        assertEquals(testClass.testFunction910(), 910);
    }

    @Test
    void test911() {
        assertEquals(testClass.testFunction911(), 911);
    }

    @Test
    void test912() {
        assertEquals(testClass.testFunction912(), 912);
    }

    @Test
    void test913() {
        assertEquals(testClass.testFunction913(), 913);
    }

    @Test
    void test914() {
        assertEquals(testClass.testFunction914(), 914);
    }

    @Test
    void test915() {
        assertEquals(testClass.testFunction915(), 915);
    }

    @Test
    void test916() {
        assertEquals(testClass.testFunction916(), 916);
    }

    @Test
    void test917() {
        assertEquals(testClass.testFunction917(), 917);
    }

    @Test
    void test918() {
        assertEquals(testClass.testFunction918(), 918);
    }

    @Test
    void test919() {
        assertEquals(testClass.testFunction919(), 919);
    }

    @Test
    void test920() {
        assertEquals(testClass.testFunction920(), 920);
    }

    @Test
    void test921() {
        assertEquals(testClass.testFunction921(), 921);
    }

    @Test
    void test922() {
        assertEquals(testClass.testFunction922(), 922);
    }

    @Test
    void test923() {
        assertEquals(testClass.testFunction923(), 923);
    }

    @Test
    void test924() {
        assertEquals(testClass.testFunction924(), 924);
    }

    @Test
    void test925() {
        assertEquals(testClass.testFunction925(), 925);
    }

    @Test
    void test926() {
        assertEquals(testClass.testFunction926(), 926);
    }

    @Test
    void test927() {
        assertEquals(testClass.testFunction927(), 927);
    }

    @Test
    void test928() {
        assertEquals(testClass.testFunction928(), 928);
    }

    @Test
    void test929() {
        assertEquals(testClass.testFunction929(), 929);
    }

    @Test
    void test930() {
        assertEquals(testClass.testFunction930(), 930);
    }

    @Test
    void test931() {
        assertEquals(testClass.testFunction931(), 931);
    }

    @Test
    void test932() {
        assertEquals(testClass.testFunction932(), 932);
    }

    @Test
    void test933() {
        assertEquals(testClass.testFunction933(), 933);
    }

    @Test
    void test934() {
        assertEquals(testClass.testFunction934(), 934);
    }

    @Test
    void test935() {
        assertEquals(testClass.testFunction935(), 935);
    }

    @Test
    void test936() {
        assertEquals(testClass.testFunction936(), 936);
    }

    @Test
    void test937() {
        assertEquals(testClass.testFunction937(), 937);
    }

    @Test
    void test938() {
        assertEquals(testClass.testFunction938(), 938);
    }

    @Test
    void test939() {
        assertEquals(testClass.testFunction939(), 939);
    }

    @Test
    void test940() {
        assertEquals(testClass.testFunction940(), 940);
    }

    @Test
    void test941() {
        assertEquals(testClass.testFunction941(), 941);
    }

    @Test
    void test942() {
        assertEquals(testClass.testFunction942(), 942);
    }

    @Test
    void test943() {
        assertEquals(testClass.testFunction943(), 943);
    }

    @Test
    void test944() {
        assertEquals(testClass.testFunction944(), 944);
    }

    @Test
    void test945() {
        assertEquals(testClass.testFunction945(), 945);
    }

    @Test
    void test946() {
        assertEquals(testClass.testFunction946(), 946);
    }

    @Test
    void test947() {
        assertEquals(testClass.testFunction947(), 947);
    }

    @Test
    void test948() {
        assertEquals(testClass.testFunction948(), 948);
    }

    @Test
    void test949() {
        assertEquals(testClass.testFunction949(), 949);
    }

    @Test
    void test950() {
        assertEquals(testClass.testFunction950(), 950);
    }

    @Test
    void test951() {
        assertEquals(testClass.testFunction951(), 951);
    }

    @Test
    void test952() {
        assertEquals(testClass.testFunction952(), 952);
    }

    @Test
    void test953() {
        assertEquals(testClass.testFunction953(), 953);
    }

    @Test
    void test954() {
        assertEquals(testClass.testFunction954(), 954);
    }

    @Test
    void test955() {
        assertEquals(testClass.testFunction955(), 955);
    }

    @Test
    void test956() {
        assertEquals(testClass.testFunction956(), 956);
    }

    @Test
    void test957() {
        assertEquals(testClass.testFunction957(), 957);
    }

    @Test
    void test958() {
        assertEquals(testClass.testFunction958(), 958);
    }

    @Test
    void test959() {
        assertEquals(testClass.testFunction959(), 959);
    }

    @Test
    void test960() {
        assertEquals(testClass.testFunction960(), 960);
    }

    @Test
    void test961() {
        assertEquals(testClass.testFunction961(), 961);
    }

    @Test
    void test962() {
        assertEquals(testClass.testFunction962(), 962);
    }

    @Test
    void test963() {
        assertEquals(testClass.testFunction963(), 963);
    }

    @Test
    void test964() {
        assertEquals(testClass.testFunction964(), 964);
    }

    @Test
    void test965() {
        assertEquals(testClass.testFunction965(), 965);
    }

    @Test
    void test966() {
        assertEquals(testClass.testFunction966(), 966);
    }

    @Test
    void test967() {
        assertEquals(testClass.testFunction967(), 967);
    }

    @Test
    void test968() {
        assertEquals(testClass.testFunction968(), 968);
    }

    @Test
    void test969() {
        assertEquals(testClass.testFunction969(), 969);
    }

    @Test
    void test970() {
        assertEquals(testClass.testFunction970(), 970);
    }

    @Test
    void test971() {
        assertEquals(testClass.testFunction971(), 971);
    }

    @Test
    void test972() {
        assertEquals(testClass.testFunction972(), 972);
    }

    @Test
    void test973() {
        assertEquals(testClass.testFunction973(), 973);
    }

    @Test
    void test974() {
        assertEquals(testClass.testFunction974(), 974);
    }

    @Test
    void test975() {
        assertEquals(testClass.testFunction975(), 975);
    }

    @Test
    void test976() {
        assertEquals(testClass.testFunction976(), 976);
    }

    @Test
    void test977() {
        assertEquals(testClass.testFunction977(), 977);
    }

    @Test
    void test978() {
        assertEquals(testClass.testFunction978(), 978);
    }

    @Test
    void test979() {
        assertEquals(testClass.testFunction979(), 979);
    }

    @Test
    void test980() {
        assertEquals(testClass.testFunction980(), 980);
    }

    @Test
    void test981() {
        assertEquals(testClass.testFunction981(), 981);
    }

    @Test
    void test982() {
        assertEquals(testClass.testFunction982(), 982);
    }

    @Test
    void test983() {
        assertEquals(testClass.testFunction983(), 983);
    }

    @Test
    void test984() {
        assertEquals(testClass.testFunction984(), 984);
    }

    @Test
    void test985() {
        assertEquals(testClass.testFunction985(), 985);
    }

    @Test
    void test986() {
        assertEquals(testClass.testFunction986(), 986);
    }

    @Test
    void test987() {
        assertEquals(testClass.testFunction987(), 987);
    }

    @Test
    void test988() {
        assertEquals(testClass.testFunction988(), 988);
    }

    @Test
    void test989() {
        assertEquals(testClass.testFunction989(), 989);
    }

    @Test
    void test990() {
        assertEquals(testClass.testFunction990(), 990);
    }

    @Test
    void test991() {
        assertEquals(testClass.testFunction991(), 991);
    }

    @Test
    void test992() {
        assertEquals(testClass.testFunction992(), 992);
    }

    @Test
    void test993() {
        assertEquals(testClass.testFunction993(), 993);
    }

    @Test
    void test994() {
        assertEquals(testClass.testFunction994(), 994);
    }

    @Test
    void test995() {
        assertEquals(testClass.testFunction995(), 995);
    }

    @Test
    void test996() {
        assertEquals(testClass.testFunction996(), 996);
    }

    @Test
    void test997() {
        assertEquals(testClass.testFunction997(), 997);
    }

    @Test
    void test998() {
        assertEquals(testClass.testFunction998(), 998);
    }

    @Test
    void test999() {
        assertEquals(testClass.testFunction999(), 999);
    }

    @Test
    void test1000() {
        assertEquals(testClass.testFunction1000(), 1000);
    }

    @Test
    void test1001() {
        assertEquals(testClass.testFunction1001(), 1001);
    }

    @Test
    void test1002() {
        assertEquals(testClass.testFunction1002(), 1002);
    }

    @Test
    void test1003() {
        assertEquals(testClass.testFunction1003(), 1003);
    }

    @Test
    void test1004() {
        assertEquals(testClass.testFunction1004(), 1004);
    }

    @Test
    void test1005() {
        assertEquals(testClass.testFunction1005(), 1005);
    }

    @Test
    void test1006() {
        assertEquals(testClass.testFunction1006(), 1006);
    }

    @Test
    void test1007() {
        assertEquals(testClass.testFunction1007(), 1007);
    }

    @Test
    void test1008() {
        assertEquals(testClass.testFunction1008(), 1008);
    }

    @Test
    void test1009() {
        assertEquals(testClass.testFunction1009(), 1009);
    }

    @Test
    void test1010() {
        assertEquals(testClass.testFunction1010(), 1010);
    }

    @Test
    void test1011() {
        assertEquals(testClass.testFunction1011(), 1011);
    }

    @Test
    void test1012() {
        assertEquals(testClass.testFunction1012(), 1012);
    }

    @Test
    void test1013() {
        assertEquals(testClass.testFunction1013(), 1013);
    }

    @Test
    void test1014() {
        assertEquals(testClass.testFunction1014(), 1014);
    }

    @Test
    void test1015() {
        assertEquals(testClass.testFunction1015(), 1015);
    }

    @Test
    void test1016() {
        assertEquals(testClass.testFunction1016(), 1016);
    }

    @Test
    void test1017() {
        assertEquals(testClass.testFunction1017(), 1017);
    }

    @Test
    void test1018() {
        assertEquals(testClass.testFunction1018(), 1018);
    }

    @Test
    void test1019() {
        assertEquals(testClass.testFunction1019(), 1019);
    }

    @Test
    void test1020() {
        assertEquals(testClass.testFunction1020(), 1020);
    }

    @Test
    void test1021() {
        assertEquals(testClass.testFunction1021(), 1021);
    }

    @Test
    void test1022() {
        assertEquals(testClass.testFunction1022(), 1022);
    }

    @Test
    void test1023() {
        assertEquals(testClass.testFunction1023(), 1023);
    }

    @Test
    void test1024() {
        assertEquals(testClass.testFunction1024(), 1024);
    }

    @Test
    void test1025() {
        assertEquals(testClass.testFunction1025(), 1025);
    }

    @Test
    void test1026() {
        assertEquals(testClass.testFunction1026(), 1026);
    }

    @Test
    void test1027() {
        assertEquals(testClass.testFunction1027(), 1027);
    }

    @Test
    void test1028() {
        assertEquals(testClass.testFunction1028(), 1028);
    }

    @Test
    void test1029() {
        assertEquals(testClass.testFunction1029(), 1029);
    }

    @Test
    void test1030() {
        assertEquals(testClass.testFunction1030(), 1030);
    }

    @Test
    void test1031() {
        assertEquals(testClass.testFunction1031(), 1031);
    }

    @Test
    void test1032() {
        assertEquals(testClass.testFunction1032(), 1032);
    }

    @Test
    void test1033() {
        assertEquals(testClass.testFunction1033(), 1033);
    }

    @Test
    void test1034() {
        assertEquals(testClass.testFunction1034(), 1034);
    }

    @Test
    void test1035() {
        assertEquals(testClass.testFunction1035(), 1035);
    }

    @Test
    void test1036() {
        assertEquals(testClass.testFunction1036(), 1036);
    }

    @Test
    void test1037() {
        assertEquals(testClass.testFunction1037(), 1037);
    }

    @Test
    void test1038() {
        assertEquals(testClass.testFunction1038(), 1038);
    }

    @Test
    void test1039() {
        assertEquals(testClass.testFunction1039(), 1039);
    }

    @Test
    void test1040() {
        assertEquals(testClass.testFunction1040(), 1040);
    }

    @Test
    void test1041() {
        assertEquals(testClass.testFunction1041(), 1041);
    }

    @Test
    void test1042() {
        assertEquals(testClass.testFunction1042(), 1042);
    }

    @Test
    void test1043() {
        assertEquals(testClass.testFunction1043(), 1043);
    }

    @Test
    void test1044() {
        assertEquals(testClass.testFunction1044(), 1044);
    }

    @Test
    void test1045() {
        assertEquals(testClass.testFunction1045(), 1045);
    }

    @Test
    void test1046() {
        assertEquals(testClass.testFunction1046(), 1046);
    }

    @Test
    void test1047() {
        assertEquals(testClass.testFunction1047(), 1047);
    }

    @Test
    void test1048() {
        assertEquals(testClass.testFunction1048(), 1048);
    }

    @Test
    void test1049() {
        assertEquals(testClass.testFunction1049(), 1049);
    }

    @Test
    void test1050() {
        assertEquals(testClass.testFunction1050(), 1050);
    }

    @Test
    void test1051() {
        assertEquals(testClass.testFunction1051(), 1051);
    }

    @Test
    void test1052() {
        assertEquals(testClass.testFunction1052(), 1052);
    }

    @Test
    void test1053() {
        assertEquals(testClass.testFunction1053(), 1053);
    }

    @Test
    void test1054() {
        assertEquals(testClass.testFunction1054(), 1054);
    }

    @Test
    void test1055() {
        assertEquals(testClass.testFunction1055(), 1055);
    }

    @Test
    void test1056() {
        assertEquals(testClass.testFunction1056(), 1056);
    }

    @Test
    void test1057() {
        assertEquals(testClass.testFunction1057(), 1057);
    }

    @Test
    void test1058() {
        assertEquals(testClass.testFunction1058(), 1058);
    }

    @Test
    void test1059() {
        assertEquals(testClass.testFunction1059(), 1059);
    }

    @Test
    void test1060() {
        assertEquals(testClass.testFunction1060(), 1060);
    }

    @Test
    void test1061() {
        assertEquals(testClass.testFunction1061(), 1061);
    }

    @Test
    void test1062() {
        assertEquals(testClass.testFunction1062(), 1062);
    }

    @Test
    void test1063() {
        assertEquals(testClass.testFunction1063(), 1063);
    }

    @Test
    void test1064() {
        assertEquals(testClass.testFunction1064(), 1064);
    }

    @Test
    void test1065() {
        assertEquals(testClass.testFunction1065(), 1065);
    }

    @Test
    void test1066() {
        assertEquals(testClass.testFunction1066(), 1066);
    }

    @Test
    void test1067() {
        assertEquals(testClass.testFunction1067(), 1067);
    }

    @Test
    void test1068() {
        assertEquals(testClass.testFunction1068(), 1068);
    }

    @Test
    void test1069() {
        assertEquals(testClass.testFunction1069(), 1069);
    }

    @Test
    void test1070() {
        assertEquals(testClass.testFunction1070(), 1070);
    }

    @Test
    void test1071() {
        assertEquals(testClass.testFunction1071(), 1071);
    }

    @Test
    void test1072() {
        assertEquals(testClass.testFunction1072(), 1072);
    }

    @Test
    void test1073() {
        assertEquals(testClass.testFunction1073(), 1073);
    }

    @Test
    void test1074() {
        assertEquals(testClass.testFunction1074(), 1074);
    }

    @Test
    void test1075() {
        assertEquals(testClass.testFunction1075(), 1075);
    }

    @Test
    void test1076() {
        assertEquals(testClass.testFunction1076(), 1076);
    }

    @Test
    void test1077() {
        assertEquals(testClass.testFunction1077(), 1077);
    }

    @Test
    void test1078() {
        assertEquals(testClass.testFunction1078(), 1078);
    }

    @Test
    void test1079() {
        assertEquals(testClass.testFunction1079(), 1079);
    }

    @Test
    void test1080() {
        assertEquals(testClass.testFunction1080(), 1080);
    }

    @Test
    void test1081() {
        assertEquals(testClass.testFunction1081(), 1081);
    }

    @Test
    void test1082() {
        assertEquals(testClass.testFunction1082(), 1082);
    }

    @Test
    void test1083() {
        assertEquals(testClass.testFunction1083(), 1083);
    }

    @Test
    void test1084() {
        assertEquals(testClass.testFunction1084(), 1084);
    }

    @Test
    void test1085() {
        assertEquals(testClass.testFunction1085(), 1085);
    }

    @Test
    void test1086() {
        assertEquals(testClass.testFunction1086(), 1086);
    }

    @Test
    void test1087() {
        assertEquals(testClass.testFunction1087(), 1087);
    }

    @Test
    void test1088() {
        assertEquals(testClass.testFunction1088(), 1088);
    }

    @Test
    void test1089() {
        assertEquals(testClass.testFunction1089(), 1089);
    }

    @Test
    void test1090() {
        assertEquals(testClass.testFunction1090(), 1090);
    }

    @Test
    void test1091() {
        assertEquals(testClass.testFunction1091(), 1091);
    }

    @Test
    void test1092() {
        assertEquals(testClass.testFunction1092(), 1092);
    }

    @Test
    void test1093() {
        assertEquals(testClass.testFunction1093(), 1093);
    }

    @Test
    void test1094() {
        assertEquals(testClass.testFunction1094(), 1094);
    }

    @Test
    void test1095() {
        assertEquals(testClass.testFunction1095(), 1095);
    }

    @Test
    void test1096() {
        assertEquals(testClass.testFunction1096(), 1096);
    }

    @Test
    void test1097() {
        assertEquals(testClass.testFunction1097(), 1097);
    }

    @Test
    void test1098() {
        assertEquals(testClass.testFunction1098(), 1098);
    }

    @Test
    void test1099() {
        assertEquals(testClass.testFunction1099(), 1099);
    }

    @Test
    void test1100() {
        assertEquals(testClass.testFunction1100(), 1100);
    }

}
