package bg.sofia.uni.fmi.mjt.cookingcompass.request;

public interface Request {
    String buildURI();
}
