package bg.sofia.uni.fmi.mjt.cookingcompass.response.wrappers;

public interface Wrapper<T> {
    T unwrap();

}
