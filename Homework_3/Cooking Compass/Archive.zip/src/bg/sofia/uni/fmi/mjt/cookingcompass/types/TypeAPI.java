package bg.sofia.uni.fmi.mjt.cookingcompass.types;

public interface TypeAPI {
    String value();
}
